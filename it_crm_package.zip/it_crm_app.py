
try:
    import streamlit as st
except ModuleNotFoundError:
    raise ModuleNotFoundError("Streamlit is not installed. Please run 'pip install streamlit' before executing this script.")

import sqlite3
from datetime import datetime

# --- Database Setup ---
conn = sqlite3.connect("it_crm.db", check_same_thread=False)
c = conn.cursor()

c.execute("""CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    phone TEXT,
    company TEXT
)""")

c.execute("""CREATE TABLE IF NOT EXISTS engineers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    mobile TEXT,
    email TEXT
)""")

c.execute("""CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    issue TEXT,
    date_created TEXT,
    status TEXT,
    priority TEXT,
    assigned_engineer INTEGER,
    FOREIGN KEY(client_id) REFERENCES clients(id),
    FOREIGN KEY(assigned_engineer) REFERENCES engineers(id)
)""")

conn.commit()

# --- Helper Functions ---
def add_client(name, email, phone, company):
    c.execute("INSERT INTO clients (name, email, phone, company) VALUES (?, ?, ?, ?)", (name, email, phone, company))
    conn.commit()

def get_clients():
    return c.execute("SELECT * FROM clients").fetchall()

def add_engineer(name, mobile, email):
    c.execute("INSERT INTO engineers (name, mobile, email) VALUES (?, ?, ?)", (name, mobile, email))
    conn.commit()

def get_engineers():
    return c.execute("SELECT * FROM engineers").fetchall()

def add_ticket(client_id, issue, status, priority, assigned_engineer):
    c.execute("INSERT INTO tickets (client_id, issue, date_created, status, priority, assigned_engineer) VALUES (?, ?, ?, ?, ?, ?)",
              (client_id, issue, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), status, priority, assigned_engineer))
    conn.commit()

def get_tickets():
    return c.execute("""SELECT tickets.id, clients.name, tickets.issue, tickets.date_created, tickets.status,
                        tickets.priority, engineers.name FROM tickets
                        JOIN clients ON tickets.client_id = clients.id
                        LEFT JOIN engineers ON tickets.assigned_engineer = engineers.id""").fetchall()

# --- Streamlit UI ---
st.title("IT CRM Web App")

menu = ["Dashboard", "Add Client", "Add Engineer", "Create Ticket"]
choice = st.sidebar.selectbox("Menu", menu)

if choice == "Dashboard":
    st.header("📋 Ticket Dashboard")
    tickets = get_tickets()
    if tickets:
        for t in tickets:
            st.write(f"**Ticket ID:** {t[0]} | **Client:** {t[1]} | **Issue:** {t[2]}")
            st.write(f"**Date:** {t[3]} | **Status:** {t[4]} | **Priority:** {t[5]} | **Engineer:** {t[6]}")
            st.markdown("---")
    else:
        st.info("No tickets yet.")

elif choice == "Add Client":
    st.header("➕ Add New Client")
    with st.form("client_form"):
        name = st.text_input("Client Name")
        email = st.text_input("Email")
        phone = st.text_input("Phone")
        company = st.text_input("Company")
        submit = st.form_submit_button("Add Client")
        if submit:
            add_client(name, email, phone, company)
            st.success("Client added successfully")

elif choice == "Add Engineer":
    st.header("👷 Add New Engineer")
    with st.form("engineer_form"):
        name = st.text_input("Engineer Name")
        mobile = st.text_input("Mobile")
        email = st.text_input("Email")
        submit = st.form_submit_button("Add Engineer")
        if submit:
            add_engineer(name, mobile, email)
            st.success("Engineer added successfully")

elif choice == "Create Ticket":
    st.header("🎫 Create New Ticket")
    clients = get_clients()
    engineers = get_engineers()

    if not clients:
        st.warning("Add clients first.")
    elif not engineers:
        st.warning("Add engineers first.")
    else:
        with st.form("ticket_form"):
            client = st.selectbox("Select Client", clients, format_func=lambda x: x[1])
            issue = st.text_area("Issue Description")
            status = st.selectbox("Status", ["Open", "In Progress", "Closed"])
            priority = st.selectbox("Priority", ["Low", "Medium", "High"])
            engineer = st.selectbox("Assign Engineer", engineers, format_func=lambda x: x[1])
            submit = st.form_submit_button("Create Ticket")
            if submit:
                add_ticket(client[0], issue, status, priority, engineer[0])
                st.success("Ticket created successfully")
